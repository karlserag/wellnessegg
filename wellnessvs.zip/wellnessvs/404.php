<?php get_header(); ?>

<main class="container" style="text-align: center; padding: 80px 0;">
  <h1 style="font-size: 48px;">404</h1>
  <p style="font-size: 18px; color: #555;">
    <?php _e('Sorry, the page you’re looking for doesn’t exist.', 'wellness'); ?>
  </p>
  <a href="<?php echo esc_url(home_url('/')); ?>" class="btn" style="margin-top: 20px;">
    <?php _e('Back to Home', 'wellness'); ?>
  </a>
</main>

<?php get_footer(); ?>
