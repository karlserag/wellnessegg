<?php
defined('ABSPATH') || exit;

get_header();
?>

<main class="container" style="padding: 60px 0;">
  <h1><?php _e('Your Cart', 'wellness'); ?></h1>

  <?php if (WC()->cart->get_cart_contents_count() > 0) : ?>
    <form class="woocommerce-cart-form" action="<?php echo esc_url(wc_get_cart_url()); ?>" method="post">
      <table class="shop_table shop_table_responsive cart" style="width: 100%; border-collapse: collapse;">
        <thead>
          <tr>
            <th><?php _e('Product', 'wellness'); ?></th>
            <th><?php _e('Price', 'wellness'); ?></th>
            <th><?php _e('Quantity', 'wellness'); ?></th>
            <th><?php _e('Total', 'wellness'); ?></th>
            <th><?php _e('Remove', 'wellness'); ?></th>
          </tr>
        </thead>
        <tbody>
          <?php foreach (WC()->cart->get_cart() as $cart_item_key => $cart_item) :
            $_product = $cart_item['data'];
            if ($_product && $_product->exists() && $cart_item['quantity'] > 0) :
              $product_id = $cart_item['product_id'];
          ?>
            <tr>
              <td><?php echo $_product->get_name(); ?></td>
              <td><?php echo wc_price($_product->get_price()); ?></td>
              <td>
                <?php
                echo wc_quantity_input([
                  'input_name'  => "cart[{$cart_item_key}][qty]",
                  'input_value' => $cart_item['quantity'],
                ], $_product, false);
                ?>
              </td>
              <td><?php echo wc_price($_product->get_price() * $cart_item['quantity']); ?></td>
              <td><?php
                echo apply_filters('woocommerce_cart_item_remove_link', sprintf(
                  '<a href="%s" class="remove" aria-label="%s">&times;</a>',
                  esc_url(wc_get_cart_remove_url($cart_item_key)),
                  __('Remove this item', 'wellness')
                ), $cart_item_key);
              ?></td>
            </tr>
          <?php endif; endforeach; ?>
        </tbody>
      </table>

      <div class="cart-actions" style="margin-top: 20px;">
        <button type="submit" class="btn" name="update_cart"><?php _e('Update Cart', 'wellness'); ?></button>
        <?php wp_nonce_field('woocommerce-cart'); ?>
      </div>
    </form>

    <div class="cart-totals" style="margin-top: 40px;">
      <?php woocommerce_cart_totals(); ?>
      <a href="<?php echo esc_url(wc_get_checkout_url()); ?>" class="btn" style="margin-top: 20px;">
        <?php _e('Proceed to Checkout', 'wellness'); ?>
      </a>
    </div>

  <?php else : ?>
    <p><?php _e('Your cart is currently empty.', 'wellness'); ?></p>
    <a href="<?php echo esc_url(home_url('/shop')); ?>" class="btn"><?php _e('Return to Shop', 'wellness'); ?></a>
  <?php endif; ?>
</main>

<?php get_footer(); ?>
