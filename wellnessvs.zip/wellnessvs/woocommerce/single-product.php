<?php
defined('ABSPATH') || exit;

get_header();
?>

<main class="container" style="padding: 60px 0;">
  <?php
  while (have_posts()) : the_post();
    global $product;
  ?>

    <div class="single-product-wrapper" style="display: flex; flex-wrap: wrap; gap: 40px;">
      
      <!-- صورة المنتج -->
      <div class="product-image" style="flex: 1 1 300px; text-align: center;">
        <?php echo $product->get_image('large'); ?>
      </div>

      <!-- تفاصيل المنتج -->
      <div class="product-details" style="flex: 1 1 400px;">
        <h1 style="font-size: 28px; margin-bottom: 10px;"><?php the_title(); ?></h1>

        <div class="product-price" style="font-size: 20px; font-weight: bold; margin-bottom: 15px;">
          <?php echo $product->get_price_html(); ?>
        </div>

        <div class="product-description" style="margin-bottom: 20px;">
          <?php the_content(); ?>
        </div>

        <?php woocommerce_template_single_add_to_cart(); ?>

        <div class="product-meta" style="margin-top: 30px; font-size: 14px; color: #777;">
          <?php do_action('woocommerce_product_meta_start'); ?>
          <p><?php _e('SKU:', 'wellness'); ?> <?php echo $product->get_sku(); ?></p>
          <p><?php _e('Category:', 'wellness'); ?> <?php echo wc_get_product_category_list($product->get_id()); ?></p>
          <?php do_action('woocommerce_product_meta_end'); ?>
        </div>
      </div>

    </div>

  <?php endwhile; ?>
</main>

<?php get_footer(); ?>
