<?php
/* Template Name: Register Page */

if (is_user_logged_in()) {
  wp_redirect(home_url('/my-account'));
  exit;
}

$register_error = '';
$register_success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $username = sanitize_user($_POST['username']);
  $email = sanitize_email($_POST['email']);
  $password = $_POST['password'];

  if (username_exists($username) || email_exists($email)) {
    $register_error = __('Username or email already exists.', 'wellness');
  } else {
    $user_id = wp_create_user($username, $password, $email);
    if (is_wp_error($user_id)) {
      $register_error = $user_id->get_error_message();
    } else {
      $register_success = __('Registration successful. You can now log in.', 'wellness');
    }
  }
}

get_header();
?>

<main class="container auth-page">
  <div class="auth-box">
    <h2><?php _e('Register', 'wellness'); ?></h2>

    <?php if (!empty($register_error)) : ?>
      <p class="error"><?php echo esc_html($register_error); ?></p>
    <?php elseif (!empty($register_success)) : ?>
      <p class="success"><?php echo esc_html($register_success); ?></p>
    <?php endif; ?>

    <form method="post">
      <input type="text" name="username" placeholder="<?php _e('Username', 'wellness'); ?>" required>
      <input type="email" name="email" placeholder="<?php _e('Email', 'wellness'); ?>" required>
      <input type="password" name="password" placeholder="<?php _e('Password', 'wellness'); ?>" required>
      <button type="submit" class="btn"><?php _e('Register', 'wellness'); ?></button>
    </form>

    <p style="margin-top: 20px;">
      <a href="<?php echo esc_url(home_url('/login')); ?>"><?php _e('Already have an account? Login', 'wellness'); ?></a>
    </p>
  </div>
</main>

<?php get_footer(); ?>
