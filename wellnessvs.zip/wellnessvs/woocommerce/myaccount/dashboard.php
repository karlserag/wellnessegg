<?php
defined('ABSPATH') || exit;

?>

<div class="custom-account-dashboard" style="padding: 40px 0;">
  <h2><?php _e('My Account', 'wellness'); ?></h2>

  <p>
    <?php
    printf(
      __('Hello %1$s (not %1$s? <a href="%2$s">Log out</a>)', 'wellness'),
      esc_html(wp_get_current_user()->display_name),
      esc_url(wc_logout_url())
    );
    ?>
  </p>

  <p>
    <?php _e('From your account dashboard you can view your', 'wellness'); ?>
    <a href="<?php echo esc_url(wc_get_endpoint_url('orders')); ?>"><?php _e('recent orders', 'wellness'); ?></a>,
    <a href="<?php echo esc_url(wc_get_endpoint_url('edit-address')); ?>"><?php _e('manage your addresses', 'wellness'); ?></a>, 
    <?php _e('and', 'wellness'); ?>
    <a href="<?php echo esc_url(wc_get_endpoint_url('edit-account')); ?>"><?php _e('edit your account details.', 'wellness'); ?></a>
  </p>

  <div class="account-links-grid">
    <a class="account-link" href="<?php echo esc_url(wc_get_endpoint_url('orders')); ?>">
      <?php _e('My Orders', 'wellness'); ?>
    </a>
    <a class="account-link" href="<?php echo esc_url(wc_get_endpoint_url('edit-address')); ?>">
      <?php _e('Addresses', 'wellness'); ?>
    </a>
    <a class="account-link" href="<?php echo esc_url(wc_get_endpoint_url('edit-account')); ?>">
      <?php _e('Account Info', 'wellness'); ?>
    </a>
    <a class="account-link" href="<?php echo esc_url(wc_get_endpoint_url('customer-logout')); ?>">
      <?php _e('Log Out', 'wellness'); ?>
    </a>
  </div>
</div>
