<?php
defined('ABSPATH') || exit;

global $product;

if (empty($product) || !$product->is_visible()) {
  return;
}
?>

<li <?php wc_product_class('custom-product-card', $product); ?>>
  <a href="<?php the_permalink(); ?>" class="product-link">
    <?php
      woocommerce_show_product_loop_sale_flash();
      woocommerce_template_loop_product_thumbnail();
    ?>

    <h2 class="woocommerce-loop-product__title"><?php the_title(); ?></h2>
    <?php woocommerce_template_loop_price(); ?>
  </a>

  <?php woocommerce_template_loop_add_to_cart(); ?>
</li>
