<?php
defined('ABSPATH') || exit;

$customer_orders = wc_get_orders([
  'customer' => get_current_user_id(),
  'limit'    => -1,
  'orderby'  => 'date',
  'order'    => 'DESC'
]);
?>

<div class="account-orders-section" style="padding: 40px 0;">
  <h2><?php _e('My Orders', 'wellness'); ?></h2>

  <?php if (!empty($customer_orders)) : ?>
    <table class="shop_table my_account_orders" style="width: 100%; border-collapse: collapse;">
      <thead>
        <tr>
          <th><?php _e('Order', 'wellness'); ?></th>
          <th><?php _e('Date', 'wellness'); ?></th>
          <th><?php _e('Status', 'wellness'); ?></th>
          <th><?php _e('Total', 'wellness'); ?></th>
          <th><?php _e('Actions', 'wellness'); ?></th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($customer_orders as $order) : ?>
          <tr>
            <td>#<?php echo $order->get_order_number(); ?></td>
            <td><?php echo wc_format_datetime($order->get_date_created()); ?></td>
            <td><?php echo wc_get_order_status_name($order->get_status()); ?></td>
            <td><?php echo $order->get_formatted_order_total(); ?></td>
            <td>
              <a href="<?php echo esc_url($order->get_view_order_url()); ?>" class="btn btn-small">
                <?php _e('View', 'wellness'); ?>
              </a>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  <?php else : ?>
    <p><?php _e('You have not placed any orders yet.', 'wellness'); ?></p>
  <?php endif; ?>
</div>
