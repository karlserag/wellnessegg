<?php
/* Template Name: Admin Orders Page */

if (!current_user_can('manage_woocommerce')) {
  wp_redirect(home_url());
  exit;
}

get_header();

$orders = wc_get_orders([
  'limit'    => -1,
  'orderby'  => 'date',
  'order'    => 'DESC',
]);
?>

<main class="container admin-orders-page">
  <h2><?php _e('All Orders', 'wellness'); ?></h2>

  <?php if ($orders) : ?>
    <table class="admin-orders-table" style="width: 100%; border-collapse: collapse; margin-top: 30px;">
      <thead>
        <tr>
          <th><?php _e('Order #', 'wellness'); ?></th>
          <th><?php _e('Customer', 'wellness'); ?></th>
          <th><?php _e('Date', 'wellness'); ?></th>
          <th><?php _e('Status', 'wellness'); ?></th>
          <th><?php _e('Total', 'wellness'); ?></th>
          <th><?php _e('View', 'wellness'); ?></th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($orders as $order) : ?>
          <tr>
            <td>#<?php echo $order->get_order_number(); ?></td>
            <td><?php echo $order->get_billing_first_name() . ' ' . $order->get_billing_last_name(); ?></td>
            <td><?php echo wc_format_datetime($order->get_date_created()); ?></td>
            <td><?php echo wc_get_order_status_name($order->get_status()); ?></td>
            <td><?php echo $order->get_formatted_order_total(); ?></td>
            <td>
              <a href="<?php echo esc_url(get_edit_post_link($order->get_id())); ?>" class="btn btn-small">
                <?php _e('Manage', 'wellness'); ?>
              </a>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  <?php else : ?>
    <p><?php _e('No orders found.', 'wellness'); ?></p>
  <?php endif; ?>
</main>

<?php get_footer(); ?>
