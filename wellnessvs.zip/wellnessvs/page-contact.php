<?php
/* Template Name: Contact Page */

$contact_success = '';
$contact_error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $name = sanitize_text_field($_POST['name']);
  $email = sanitize_email($_POST['email']);
  $message = sanitize_textarea_field($_POST['message']);

  if ($name && $email && $message) {
    $to = get_option('admin_email');
    $subject = __('New Contact Message', 'wellness');
    $body = "Name: $name\nEmail: $email\nMessage:\n$message";
    $headers = ['Content-Type: text/plain; charset=UTF-8'];

    wp_mail($to, $subject, $body, $headers);

    $contact_success = __('Your message has been sent.', 'wellness');
  } else {
    $contact_error = __('Please fill out all fields.', 'wellness');
  }
}

get_header();
?>

<main class="container contact-page">
  <div class="contact-box">
    <h2><?php _e('Contact Us', 'wellness'); ?></h2>

    <?php if (!empty($contact_success)) : ?>
      <p class="success"><?php echo esc_html($contact_success); ?></p>
    <?php elseif (!empty($contact_error)) : ?>
      <p class="error"><?php echo esc_html($contact_error); ?></p>
    <?php endif; ?>

    <form method="post">
      <input type="text" name="name" placeholder="<?php _e('Your Name', 'wellness'); ?>" required>
      <input type="email" name="email" placeholder="<?php _e('Your Email', 'wellness'); ?>" required>
      <textarea name="message" placeholder="<?php _e('Your Message', 'wellness'); ?>" rows="5" required></textarea>
      <button type="submit" class="btn"><?php _e('Send Message', 'wellness'); ?></button>
    </form>
  </div>
</main>

<?php get_footer(); ?>
