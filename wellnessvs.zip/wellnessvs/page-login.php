<?php
/* Template Name: Login Page */

if (is_user_logged_in()) {
  wp_redirect(home_url('/my-account'));
  exit;
}

$login_error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $creds = [
    'user_login'    => sanitize_text_field($_POST['username']),
    'user_password' => $_POST['password'],
    'remember'      => isset($_POST['remember'])
  ];

  $user = wp_signon($creds, false);

  if (is_wp_error($user)) {
    $login_error = $user->get_error_message();
  } else {
    wp_redirect(home_url('/my-account'));
    exit;
  }
}

get_header();
?>

<main class="container auth-page">
  <div class="auth-box">
    <h2><?php _e('Login', 'wellness'); ?></h2>

    <?php if (!empty($login_error)) : ?>
      <p class="error"><?php echo esc_html($login_error); ?></p>
    <?php endif; ?>

    <form method="post">
      <input type="text" name="username" placeholder="<?php _e('Username or Email', 'wellness'); ?>" required>
      <input type="password" name="password" placeholder="<?php _e('Password', 'wellness'); ?>" required>
      <label style="display: inline-block; margin: 10px 0;">
        <input type="checkbox" name="remember">
        <?php _e('Remember me', 'wellness'); ?>
      </label>
      <button type="submit" class="btn"><?php _e('Login', 'wellness'); ?></button>
    </form>

    <p style="margin-top: 20px;">
      <a href="<?php echo esc_url(home_url('/register')); ?>"><?php _e("Don't have an account? Register", 'wellness'); ?></a>
    </p>
    <p>
      <a href="<?php echo esc_url(home_url('/reset-password')); ?>"><?php _e('Forgot your password?', 'wellness'); ?></a>
    </p>
  </div>
</main>

<?php get_footer(); ?>
