<?php get_header(); ?>

<main class="container">
  <?php while (have_posts()) : the_post(); ?>
    <article <?php post_class(); ?>>
      <h1><?php the_title(); ?></h1>
      <div class="post-meta">
        <span><?php echo get_the_date(); ?></span> |
        <span><?php the_author(); ?></span>
      </div>

      <div class="content">
        <?php the_content(); ?>
      </div>

      <div class="post-categories">
        <?php the_category(', '); ?>
      </div>

      <div class="post-tags">
        <?php the_tags('', ', ', ''); ?>
      </div>
    </article>
  <?php endwhile; ?>
</main>

<?php get_footer(); ?>
