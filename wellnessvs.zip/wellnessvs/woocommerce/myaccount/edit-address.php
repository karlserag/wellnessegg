<?php
defined('ABSPATH') || exit;

$load_address = isset($_GET['address']) ? wc_edit_address_i18n($_GET['address']) : '';

get_header();
?>

<main class="container" style="padding: 40px 0;">
  <h2><?php _e('My Addresses', 'wellness'); ?></h2>

  <?php if (!$load_address) : ?>
    <div class="address-card-grid" style="display: flex; flex-wrap: wrap; gap: 30px;">
      <div class="address-box" style="flex: 1 1 300px; border: 1px solid #eee; padding: 20px;">
        <h3><?php _e('Billing Address', 'wellness'); ?></h3>
        <address>
          <?php
          $billing = wc_get_account_formatted_address('billing');
          echo $billing ? $billing : __('You have not set up a billing address yet.', 'wellness');
          ?>
        </address>
        <a href="<?php echo esc_url(wc_get_endpoint_url('edit-address', 'billing')); ?>" class="btn">
          <?php _e('Edit', 'wellness'); ?>
        </a>
      </div>

      <div class="address-box" style="flex: 1 1 300px; border: 1px solid #eee; padding: 20px;">
        <h3><?php _e('Shipping Address', 'wellness'); ?></h3>
        <address>
          <?php
          $shipping = wc_get_account_formatted_address('shipping');
          echo $shipping ? $shipping : __('You have not set up a shipping address yet.', 'wellness');
          ?>
        </address>
        <a href="<?php echo esc_url(wc_get_endpoint_url('edit-address', 'shipping')); ?>" class="btn">
          <?php _e('Edit', 'wellness'); ?>
        </a>
      </div>
    </div>
  <?php else : ?>
    <div class="edit-address-form" style="margin-top: 40px;">
      <h3>
        <?php echo ($_GET['address'] === 'billing') ? __('Edit Billing Address', 'wellness') : __('Edit Shipping Address', 'wellness'); ?>
      </h3>
      <?php
        do_action("woocommerce_before_edit_address_form_{$load_address}");
        woocommerce_edit_address_form($load_address);
        do_action("woocommerce_after_edit_address_form_{$load_address}");
      ?>
    </div>
  <?php endif; ?>
</main>

<?php get_footer(); ?>
