<?php get_header(); ?>

<main class="container" style="padding: 60px 0;">
  <h1 style="font-size: 28px; margin-bottom: 30px;">
    <?php printf(__('Search Results for: %s', 'wellness'), get_search_query()); ?>
  </h1>

  <?php if (have_posts()) : ?>
    <?php while (have_posts()) : the_post(); ?>
      <article <?php post_class(); ?> style="margin-bottom: 40px; border-bottom: 1px solid #ddd; padding-bottom: 20px;">
        <h2 style="font-size: 22px; margin-bottom: 10px;">
          <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
        </h2>
        <div class="excerpt" style="color: #555;">
          <?php the_excerpt(); ?>
        </div>
      </article>
    <?php endwhile; ?>

    <div style="margin-top: 30px;">
      <?php the_posts_pagination(); ?>
    </div>
  <?php else : ?>
    <p style="font-size: 18px; color: #777;">
      <?php _e('No results found for your search.', 'wellness'); ?>
    </p>
  <?php endif; ?>
</main>

<?php get_footer(); ?>
