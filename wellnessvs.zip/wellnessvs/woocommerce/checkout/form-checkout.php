<?php
defined('ABSPATH') || exit;

get_header();
?>

<main class="container" style="padding: 60px 0;">
  <h1><?php _e('Checkout', 'wellness'); ?></h1>

  <?php if (!WC()->cart->get_cart_contents_count()) : ?>
    <p><?php _e('Your cart is empty.', 'wellness'); ?></p>
    <a href="<?php echo esc_url(home_url('/shop')); ?>" class="btn"><?php _e('Return to Shop', 'wellness'); ?></a>
  <?php else : ?>
    <?php do_action('woocommerce_before_checkout_form', $checkout); ?>

    <form name="checkout" method="post" class="checkout woocommerce-checkout" action="<?php echo esc_url(wc_get_checkout_url()); ?>" enctype="multipart/form-data">

      <div class="checkout-columns" style="display: flex; flex-wrap: wrap; gap: 40px;">
        
        <!-- Billing Details -->
        <div class="checkout-billing" style="flex: 1 1 300px;">
          <h2><?php _e('Billing Details', 'wellness'); ?></h2>
          <?php do_action('woocommerce_checkout_billing'); ?>
        </div>

        <!-- Order Review -->
        <div class="checkout-review" style="flex: 1 1 300px;">
          <h2><?php _e('Your Order', 'wellness'); ?></h2>
          <?php do_action('woocommerce_checkout_order_review'); ?>
        </div>

      </div>

    </form>

    <?php do_action('woocommerce_after_checkout_form', $checkout); ?>
  <?php endif; ?>
</main>

<?php get_footer(); ?>
