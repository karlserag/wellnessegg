<?php
/* Template Name: Admin Users Page */

if (!current_user_can('manage_options')) {
  wp_redirect(home_url());
  exit;
}

get_header();

$users = get_users([
  'orderby' => 'registered',
  'order'   => 'DESC',
]);
?>

<main class="container admin-users-page" style="padding: 40px 0;">
  <h2><?php _e('Registered Users', 'wellness'); ?></h2>

  <?php if ($users) : ?>
    <table class="admin-users-table" style="width: 100%; border-collapse: collapse; margin-top: 30px;">
      <thead>
        <tr>
          <th><?php _e('Username', 'wellness'); ?></th>
          <th><?php _e('Name', 'wellness'); ?></th>
          <th><?php _e('Email', 'wellness'); ?></th>
          <th><?php _e('Role', 'wellness'); ?></th>
          <th><?php _e('Registered', 'wellness'); ?></th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($users as $user) : ?>
          <tr>
            <td><?php echo esc_html($user->user_login); ?></td>
            <td><?php echo esc_html($user->first_name . ' ' . $user->last_name); ?></td>
            <td><?php echo esc_html($user->user_email); ?></td>
            <td><?php echo esc_html(implode(', ', $user->roles)); ?></td>
            <td><?php echo date('Y-m-d', strtotime($user->user_registered)); ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  <?php else : ?>
    <p><?php _e('No users found.', 'wellness'); ?></p>
  <?php endif; ?>
</main>

<?php get_footer(); ?>
