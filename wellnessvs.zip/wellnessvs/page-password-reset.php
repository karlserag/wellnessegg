<?php
/* Template Name: Reset Password Page */

$reset_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['user_email'])) {
  $email = sanitize_email($_POST['user_email']);
  if (email_exists($email)) {
    $user = get_user_by('email', $email);
    $reset_key = get_password_reset_key($user);

    $reset_url = network_site_url("wp-login.php?action=rp&key=$reset_key&login=" . rawurlencode($user->user_login), 'login');

    // إرسال الإيميل (بسيط)
    $subject = __('Password Reset Request', 'wellness');
    $message = sprintf(__('Click here to reset your password: %s', 'wellness'), $reset_url);
    wp_mail($email, $subject, $message);

    $reset_message = __('Check your email for a password reset link.', 'wellness');
  } else {
    $reset_message = __('No user found with that email.', 'wellness');
  }
}

get_header();
?>

<main class="container auth-page">
  <div class="auth-box">
    <h2><?php _e('Reset Password', 'wellness'); ?></h2>

    <?php if (!empty($reset_message)) : ?>
      <p class="success"><?php echo esc_html($reset_message); ?></p>
    <?php endif; ?>

    <form method="post">
      <input type="email" name="user_email" placeholder="<?php _e('Enter your email', 'wellness'); ?>" required>
      <button type="submit" class="btn"><?php _e('Send Reset Link', 'wellness'); ?></button>
    </form>

    <p style="margin-top: 20px;">
      <a href="<?php echo esc_url(home_url('/login')); ?>"><?php _e('Back to Login', 'wellness'); ?></a>
    </p>
  </div>
</main>

<?php get_footer(); ?>
