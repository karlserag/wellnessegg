<?php
if (!defined('ABSPATH')) {
    exit;
}

// 🟢 إعدادات الثيم الأساسية
function wellness_theme_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('automatic-feed-links');
    add_theme_support('woocommerce');
    add_theme_support('html5', ['search-form', 'gallery', 'caption']);
    add_theme_support('custom-logo');
    add_theme_support('menus');
    add_theme_support('editor-styles');
    add_theme_support('customize-selective-refresh-widgets');

    load_theme_textdomain('wellness', get_template_directory() . '/languages');
}
add_action('after_setup_theme', 'wellness_theme_setup');

// 🧠 تسجيل القوائم
function wellness_register_menus() {
    register_nav_menus([
        'primary' => __('Primary Menu', 'wellness'),
        'footer' => __('Footer Menu', 'wellness')
    ]);
}
add_action('init', 'wellness_register_menus');

// 🎨 تحميل ملفات CSS و JS
function wellness_enqueue_scripts() {
    // الأساسيات
    wp_enqueue_style('wellness-style', get_stylesheet_uri());

    // خط IBM Plex Arabic
    wp_enqueue_style('ibm-plex-arabic', 'https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Arabic:wght@400;700&display=swap', [], null);

    // CSS مخصص
    wp_enqueue_style('wellness-main-css', get_template_directory_uri() . '/assets/css/main.css', [], '1.0');

    // JS مخصص
    wp_enqueue_script('wellness-main-js', get_template_directory_uri() . '/assets/js/main.js', [], '1.0', true);

    // دعم RTL تلقائي
    if (is_rtl()) {
        wp_add_inline_style('wellness-style', 'body { direction: rtl; }');
    }
}
add_action('wp_enqueue_scripts', 'wellness_enqueue_scripts');

// 🔐 إخفاء شريط الأدمن عن غير المشرفين
if (!current_user_can('administrator')) {
    add_filter('show_admin_bar', '__return_false');
}

// 🔵 إزالة شعار WordPress من شريط الأدمن
function wellness_remove_wp_logo($wp_admin_bar) {
    if (is_user_logged_in()) {
        $wp_admin_bar->remove_node('wp-logo');
    }
}
add_action('admin_bar_menu', 'wellness_remove_wp_logo', 999);

// 🔒 إعادة توجيه wp-login.php و wp-admin إلى /login لغير المسجلين
function wellness_redirect_login_page() {
    $login_page = home_url('/login');

    if (strpos($_SERVER['REQUEST_URI'], 'wp-login.php') !== false && !is_user_logged_in()) {
        wp_redirect($login_page);
        exit;
    }

    if (strpos($_SERVER['REQUEST_URI'], 'wp-admin') !== false && !is_user_logged_in()) {
        wp_redirect($login_page);
        exit;
    }
}
add_action('init', 'wellness_redirect_login_page');

// ⚙️ تحميل ملف إعدادات الثيم
require get_template_directory() . '/inc/theme-options.php';
